function x=IC_single_pop(length,width)
close all

x=zeros(length,width);

x(1,:)=1;
